# youcog
A chrome extension that allows you to open youtube videos in an incognito window
